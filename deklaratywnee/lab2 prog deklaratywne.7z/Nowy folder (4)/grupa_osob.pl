%Program grupa_osob
%Baza wiedzy o grupie osob i ich upodobaniach
%Definiowane predykaty
%lubi/2
%opis:lubi(X,Y)-Spelniony gdy osoba x lubi osobe y
%jarosz/1
%opis jarosz(x)-spelniony gdy jest jaroszem
%nie_palacy/1
%opis: nie_palacy(x)-spelniony, gdy x nie pali papierosow.
%lubi czytac/2
%opis lubi czytac(x)-spelniony gdy x lubi czytac ksiazki
%uprawia sport/1
%opis uprawia sport(x)-spelniony gdy x uprawia sport
%===============================================================
jarosz(ola).
jarosz(ewa).
jarosz(jan).
jarosz(pawe�).
nie_palacy(ola).
nie_palacy(ewa).
nie_palacy(jan).
lubi_czytac(ola).
lubi_czytac(iza).
lubi_czytac(piotr).
uprawia_sport(ola).
uprawia_sport(jan).
uprawia_sport(piotr).
uprawia_sport(pawe�).
lubi(ola,X):-jarosz(X),uprawia_sport(X).
lubi(ewa,X):-nie_palacy(X),jarosz(X).
lubi(iza,X):-lubi_czytac(X).
lubi(iza,X):-uprawia_sport(X),nie_palacy(X).
lubi(jan,X):-uprawia_sport(X).
lubi(piotr,X):-jarosz(X),uprawia_sport(X).
lubi(piotr,X):-lubi_czytac(X).
lubi(pawel,X):-jarosz(X),uprawia_sport(X),lubi_czytac(X).

