%PROGRAM: klocki_2
%Baza wiedzy o uk�adzie klock�w
%Definiowane predykaty:
%na/2
%   pod/2
%   miedzy/3
%===============================================


%na(X,Y)
%opis: spelniony, gdy klocek x lezy
%bezposrednio na klocku Y
%  pod(X,Y)
%opis:spelniony, gdy klocek x lezy
%bezposrednio pod klockiem Y
%miedzy(X,Y,Z)
%opis:spelniony,gdy klocek X lezy miedzy
%klockami y i z
%==================================================na/2
  na(c,a).
  na(c,b).
  na(d,c).
          pod(X,Y):-na(Y,X).
  miedzy(X,Y,Z):-na(Z,X),na(X,Y).
  miedzy(X,Y,Z):-na(Y,X),na(X,Z).
%==================================================na/2

/*
Informacje o budowie programu:
PRogram skalda sie z 6 klauzyl.
Program zawiera 3 definicje relacji.
Co to sa relacje na/2 i miedzy/3.
Definicja relacji na/2 skalda sie z 3 klauzul ktore sa faktami.
Definicja relacjipod.2 sklada sie z 1 klazuli, ktora jest regula.
Definicja relacji miedzy/3 sklada sei z 2 klauzul ktore sa regulami.
*/
